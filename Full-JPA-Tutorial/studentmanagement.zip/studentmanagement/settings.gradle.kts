rootProject.name = "studentmanagement"
